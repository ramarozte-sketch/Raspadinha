package com.example.raspadinha

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import kotlin.random.Random

// ---------- Modelo ----------

private data class Symbol(val emoji: String, val prize: Int)

private val SYMBOLS = listOf(
    Symbol("🍀", 2),
    Symbol("🍒", 5),
    Symbol("⭐", 10),
    Symbol("🔔", 20),
    Symbol("💎", 50),
)

private data class Card(val cells: List<Symbol>, val prize: Int)

/** ~25% das raspadinhas têm prémio (3 símbolos iguais). Nunca há 3 iguais por acaso. */
private fun newCard(): Card {
    val winner = if (Random.nextFloat() < 0.25f) SYMBOLS.random() else null
    val pool = mutableListOf<Symbol>()
    if (winner != null) repeat(3) { pool += winner }
    while (pool.size < 9) {
        val s = SYMBOLS.random()
        if (s != winner && pool.count { it == s } < 2) pool += s
    }
    return Card(pool.shuffled(), winner?.prize ?: 0)
}

// ---------- Cores ----------

private val Ink = Color(0xFF10262B)
private val Panel = Color(0xFF1A3A41)
private val Gold = Color(0xFFE6B84A)
private val Paper = Color(0xFFF3EFE6)
private val FoilBrush = Brush.linearGradient(
    listOf(Color(0xFFB9C0C6), Color(0xFFE9EDF0), Color(0xFF9AA3AA), Color(0xFFDDE2E6))
)

// ---------- UI ----------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
private fun App() {
    var balance by remember { mutableIntStateOf(9) } // 10 € iniciais - 1 € da primeira raspadinha
    var card by remember { mutableStateOf(newCard()) }
    var cardId by remember { mutableIntStateOf(0) }
    var revealed by remember { mutableStateOf(false) }

    fun reveal() {
        if (!revealed) {
            revealed = true
            balance += card.prize
        }
    }

    fun buyNext() {
        if (revealed && balance >= 1) {
            balance -= 1
            card = newCard()
            cardId++
            revealed = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ink)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Saldo (simulado)", color = Paper.copy(alpha = 0.7f), fontSize = 14.sp)
        Text("$balance €", color = Gold, fontSize = 40.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        key(cardId) {
            ScratchCard(card = card, revealed = revealed, onReveal = { reveal() })
        }

        Spacer(Modifier.height(16.dp))
        Text(
            text = when {
                !revealed -> "Raspa os símbolos. 3 iguais ganham."
                card.prize > 0 -> "Ganhaste ${card.prize} €!"
                else -> "Sem prémio desta vez."
            },
            color = Paper,
            fontSize = 18.sp,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.weight(1f))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = { reveal() },
                enabled = !revealed,
                modifier = Modifier.weight(1f),
            ) { Text("Revelar tudo", color = if (!revealed) Paper else Color.Gray) }

            Button(
                onClick = { buyNext() },
                enabled = revealed && balance >= 1,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
            ) { Text("Nova (1 €)") }
        }
        if (balance < 1 && revealed) {
            Spacer(Modifier.height(8.dp))
            Text("Sem saldo. Fecha e abre a app para recomeçar.", color = Paper.copy(alpha = 0.7f), fontSize = 13.sp)
        }
    }
}

@Composable
private fun ScratchCard(card: Card, revealed: Boolean, onReveal: () -> Unit) {
    val foilAlpha by animateFloatAsState(
        targetValue = if (revealed) 0f else 1f,
        animationSpec = tween(450),
        label = "foil",
    )
    val path = remember { Path() }
    var tick by remember { mutableIntStateOf(0) }       // força redesenho ao raspar
    val touched = remember { HashSet<Int>() }           // células da grelha de cobertura já raspadas
    val gridN = 12

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(20.dp))
            .background(Paper),
    ) {
        // Prémios por baixo
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (r in 0 until 3) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (c in 0 until 3) {
                        Box(
                            Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White),
                            contentAlignment = Alignment.Center,
                        ) {
                            val s = card.cells[r * 3 + c]
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(s.emoji, fontSize = 34.sp)
                                Text("${s.prize} €", color = Ink, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Película raspável por cima
        if (foilAlpha > 0f) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        compositingStrategy = CompositingStrategy.Offscreen
                        alpha = foilAlpha
                    }
                    .pointerInput(Unit) {
                        fun mark(p: Offset) {
                            val cx = (p.x / size.width * gridN).toInt().coerceIn(0, gridN - 1)
                            val cy = (p.y / size.height * gridN).toInt().coerceIn(0, gridN - 1)
                            touched += cy * gridN + cx
                            if (touched.size >= gridN * gridN * 0.55f) onReveal()
                        }
                        detectDragGestures(
                            onDragStart = { p -> path.moveTo(p.x, p.y); mark(p); tick++ },
                            onDrag = { change, _ ->
                                path.lineTo(change.position.x, change.position.y)
                                mark(change.position)
                                tick++
                            },
                        )
                    },
            ) {
                val redraw = tick // lido aqui para o Canvas redesenhar a cada movimento
                drawRect(FoilBrush)
                drawPath(
                    path = path,
                    color = Color.Transparent,
                    blendMode = BlendMode.Clear,
                    style = Stroke(width = 56.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
                )
            }
        }
    }
}
